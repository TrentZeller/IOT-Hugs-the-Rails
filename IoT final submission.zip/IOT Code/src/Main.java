import java.util.Scanner;
import javax.swing.*;
import java.awt.GraphicsEnvironment;
import java.awt.GraphicsDevice;
import java.awt.Color;



class Main{
 static GraphicsDevice device = GraphicsEnvironment
        .getLocalGraphicsEnvironment().getScreenDevices()[0];
 
  public static void main(String[] args) {
    String username;
    String password;
    Scanner sc = new Scanner(System.in);
    String warn = "";
    String message = "";
    
    //login GUI
    GUI frame = new GUI();
    frame.setTitle("Login Form");
    frame.setVisible(false);
    frame.setBounds(10, 10, 370, 600);
    frame.setExtendedState(JFrame.MAXIMIZED_BOTH); 
    frame.setUndecorated(true);
    device.setFullScreenWindow(frame);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setResizable(false);
    
  
    
    
    while(frame.iot.getIsOn() == false) {
      System.out.println("");
      if (frame.stat) {
        System.out.println("");
        frame.displayStatus(frame.iot.turnOn());
        //frame.getContentPane().setBackground(Color.WHITE);
      }
    }
    frame.iot.setLoggedIn(true); 
    boolean red = false;
    while(frame.iot.getIsOn() && frame.iot.getLoggedIn()) {
      boolean warning = false;
      if(frame.iot.getLoggedIn() == false){
        warning = false;
        red = false;
        frame.sens.reset();
        frame.iot.stopTrain();
        frame.getContentPane().setBackground(Color.WHITE);
        frame.repaint();
      }
      // Detects objects on the track
      if (frame.sens.objectOnTrack()) {
        if (!warning){
          frame.iot.warningSound();
        } 
        warning = true;
        
        if(frame.iot.getSpeed() > 0) {
          warn = "Warning: Object on the Track. Suggestion: Slow down.";
        }
        else {
          warn = "Warning: Object on the Track.";
        }
        
      }

      // wheels are slipping if RPM != GPS speed
      //Converts rpm to a speed to be compared to the GPS speed
      double wheelSlippage = 1.778 * 3.14159 * 60 * frame.sens.getRPM() / 1000 / frame.iot.getSpeed(); 

      // Detects heavy wheel slippage
      if (wheelSlippage > 1.25 || wheelSlippage < 0.75) {
        if (!warning) frame.iot.warningSound();
        warning = true;
        
        warn = "Warning: Heavy wheel slippage. Suggestion: Deploy sand, slow down.";
        frame.getContentPane().setBackground(Color.RED);
        red = true;
      } else {
        red = false;
      }

      // Detects medium wheel slippage
      if ((wheelSlippage > 1.1 && wheelSlippage <= 1.25) || 
          (wheelSlippage < 0.9 && wheelSlippage >= 0.75)) {
        if (!warning) frame.iot.warningSound();
        warning = true;
        warn = "Warning: Medium wheel slippage. Suggestion: Deploy sand, slow down.";
      }

      // Detects gates ahead
      if (frame.sens.getGateDistance() > .9 && frame.sens.getGateDistance() < 1.60934) {
        if (!warning) frame.iot.warningSound();
        warning = true;
        warn = "Info: Gate found. Suggestion: Blow horn for 15 seconds.";
      } 

      // Detects arriving at a gate
      if (frame.sens.getGateDistance() < .1) {
        message = "Info: Arrived at a gate. Suggestion: Blow horn for 5 seconds.";
      } 

      // Detects incoming objects
      if (frame.sens.nearbyObjectSpeed() > 0) {
        if (!warning) frame.iot.warningSound();
        warning = true;
        warn = "Warning: Object incoming at "
                            + frame.sens.nearbyObjectSpeed() + 
                            "kph. Suggestion: Slow down.";
        
      }

      // Detects objects moving away from the train
      if (frame.sens.nearbyObjectSpeed() < 0) {
        warning = true;
        warn = "Info: Object outgoing at "
                            + frame.sens.nearbyObjectSpeed();
      }
      frame.displaySpeed(frame.iot.getSpeed());
      frame.displayRain(); 
      frame.displayRPM();
      frame.displayObj();
      frame.displayGateOpen();
      frame.displayGateDistance();
      
      if (warning == false) {
        frame.fullyOperational("Status: Fully Operational.");
        frame.getContentPane().setBackground(Color.WHITE);
      } else {
        frame.displayStatus(warn);
        if (!red) frame.getContentPane().setBackground(Color.YELLOW);
      }
    }
  
  }
}