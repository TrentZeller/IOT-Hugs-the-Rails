import java.util.*;

public class Sensors {
  private boolean data;
  private boolean rain;
  private double currentDistance;
  private double prevDistance;
  private double RPM;
  private double gateDistance;
  private boolean gateOpen;
  private boolean obstacleDetectionSensor;
  private double railFrictionSensor;
  private double timeOfFlightSensor;
  private boolean camera;

  //Initializes sensors
  public Sensors() {
    prevDistance = 0;
    currentDistance = 0;
    gateDistance = 10000000;
    data = false;
  }

  public void reset() {
    boolean data = false;
    boolean rain = false;
    double currentDistance = 0;
    double prevDistance = 0;
    double RPM = 0;
    double gateDistance = 0;
    boolean gateOpen = false;
    boolean obstacleDetectionSensor = false;
    double railFrictionSensor = 0;
    double timeOfFlightSensor = 0;
    boolean camera = false;
  }

  //Detects object on track
  public boolean objectOnTrack() {
    return obstacleDetectionSensor;
  }

  //Sets whether there is an object on track, for testing purposes
  public void toggleObjectOnTrack() {
    obstacleDetectionSensor = !obstacleDetectionSensor;
  }

  //Detects speed of nearby object via Time of Flight Sensor
  public double nearbyObjectSpeed() {
    double speed = prevDistance - currentDistance;
    return speed;
  }

  //Checks if it is raining
  public boolean isRaining() {
    return rain;
  }

  //Sets whether it is raining, for testing purposes
  public void toggleRain() {
    rain = !rain;
  }

  //Sets the RPM for testing purposes
  public void setRPM(double r) {
    RPM = r;
  }

  //Gets the RPM of the wheels
  public double getRPM() {
    return RPM;
  }

  //Gets the distance from the gate
  public double getGateDistance() {
    return gateDistance;
  }

  //Sets the distance from the gate, for testing purposes
  public void setGateDistance(double g){
    gateDistance = g;
  }

  //Checks if gate is open
  public boolean isGateOpen(){
    return gateOpen;
  }

  //Sets if the gate is open, for testing purposes
  public void toggleGate(){
    gateOpen = !gateOpen;
  }

  //Checks for movement on track
  public double movementOnTrack() {
    return timeOfFlightSensor;
  }

  //Sets data for testing purposes
  public void setDistance(double d) {
    currentDistance = d;
  }

  //Sets RPM for testing purposes
   public void setRpm(double d) {
    RPM = d;
  }

  //Sets data, for testing purposes
  public void set_data(boolean data_) {
    data = data_;
  }
}