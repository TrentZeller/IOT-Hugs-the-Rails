import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Dimension;
import javax.swing.JFrame; 
import java.util.Date;
import java.text.SimpleDateFormat;

public class GUI extends JFrame implements ActionListener {
    //sensors
    Sensors sens = new Sensors();
    IOTSystem iot = new IOTSystem();
    Date date = new Date();
    SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
    

    Container container = getContentPane();
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    //jlabels
    JLabel userLabel = new JLabel("   USERNAME");
    JLabel passwordLabel = new JLabel("   PASSWORD");
    JLabel status = new JLabel("IOT is running");
    JLabel speed = new JLabel("Speed: 0");
    JLabel rain = new JLabel("Speed: false");
    JLabel obj = new JLabel("Object On Tracks: false");
    JLabel rpm = new JLabel("RPM: 0");
    JLabel gateOpen = new JLabel("Gate Open: false");
    JLabel gateDistance = new JLabel("Gate Distance: 0");

    JTextField userTextField = new JTextField();
    JTextField textField = new JTextField();
    JPasswordField passwordField = new JPasswordField();

    //jbuttons
    JButton loginButton = new JButton("LOGIN");
    JButton brakeButton = new JButton("BRAKE");
    JButton resetButton = new JButton("RESET");
    JButton logoutButton = new JButton("LOGOUT");
    JButton incSpeedButton = new JButton("Increase Speed");
    JButton decSpeedButton = new JButton("Decrease Speed");
    JButton setRpmButton = new JButton("Set RPM");
    JButton objOnTrack = new JButton("Toggle Obj. on Track");
    JButton rainButton = new JButton("Toggle Rain");
    JButton gateButton = new JButton("Set Gate Distance");
    JButton gateOpenButton = new JButton("Toggle Gate");
    JCheckBox showPassword = new JCheckBox("Show Password");
    boolean stat = false;
 
    public GUI() {
        setLayoutManager();
        setLocationAndSize();
        addloginComponentsToContainer();
        addActionEvent();
    }
 
    public void setLayoutManager() {
        container.setLayout(null);
    }
 
    public void setLocationAndSize() {
        userLabel.setBounds(screenSize.width/2 - 300, screenSize.height/2-200, 100, 30);
        passwordLabel.setBounds(screenSize.width/2 - 300, screenSize.height/2-100, 100, 30);
        userTextField.setBounds(screenSize.width/2 - 200, screenSize.height/2-200, 150, 30);
        passwordField.setBounds(screenSize.width/2 - 200, screenSize.height/2-100, 150, 30);
        showPassword.setBounds(screenSize.width/2 - 200, screenSize.height/2- 75, 150, 30);
        //buttons
        loginButton.setBounds(screenSize.width/2 + 100, screenSize.height/2, 100, 30);
        resetButton.setBounds(screenSize.width/2 - 200, screenSize.height/2, 100, 30);
       
        logoutButton.setBounds(screenSize.width/2 + 100, screenSize.height/2, 300, 30);
        brakeButton.setBounds(screenSize.width/2 + 100, screenSize.height/2 - 50, 300, 30);
        incSpeedButton.setBounds(screenSize.width/2 + 100, screenSize.height/2 - 100, 300, 30);
        decSpeedButton.setBounds(screenSize.width/2 + 100, screenSize.height/2 - 150, 300, 30);
        setRpmButton.setBounds(screenSize.width/2 - 400, screenSize.height/2 - 200, 300, 30);
        rainButton.setBounds(screenSize.width/2 - 400, screenSize.height/2, 300, 30);
        gateButton.setBounds(screenSize.width/2 - 400, screenSize.height/2 - 50, 300, 30);
        gateOpenButton.setBounds(screenSize.width/2 - 400, screenSize.height/2 - 100, 300, 30);
        objOnTrack.setBounds(screenSize.width/2 - 400, screenSize.height/2 - 150, 300, 30);
        //logged in
        speed.setBounds(screenSize.width/2 - 200, screenSize.height/2 + 50, 1000, 300);
        rain.setBounds(screenSize.width/2 - 50, screenSize.height/2 + 50, 1000, 300);
        rpm.setBounds(screenSize.width/2 + 100, screenSize.height/2 + 50, 1000, 300);
        gateOpen.setBounds(screenSize.width/2 - 200, screenSize.height/2 + 100, 1000, 300);
        gateDistance.setBounds(screenSize.width/2 - 50, screenSize.height/2 + 100, 1000, 300);
        obj.setBounds(screenSize.width/2 + 100,screenSize.height/2 + 100,1000,300);

        status.setBounds(screenSize.width/2 - 100, screenSize.height/2 , 1000, 300);
        textField.setBounds(screenSize.width/2 - 50, screenSize.height/2 + 50, 100, 30);
        
    }
    
    public void addloginComponentsToContainer() {
        reset();
        container.add(userLabel);
        container.add(passwordLabel);
        container.add(userTextField);
        container.add(passwordField);
        container.add(showPassword);
        container.add(loginButton);
        container.add(resetButton);
    }
 
    public void reset(){
      userTextField.setText("");
      passwordField.setText("");
      container.removeAll();
      container.revalidate();
      container.repaint();
    }

    public void addDisplayConductorComponentsToContainer() {
        reset();
        //tags
        container.add(status);
        container.add(speed);
        container.add(rain);
        container.add(rpm);
        container.add(gateOpen);
        container.add(gateDistance);
        //buttons
        container.add(logoutButton);
        container.add(incSpeedButton);
        container.add(decSpeedButton);
        container.add(brakeButton);
        
        
        stat = true;
    }

    public void addDisplayAdminComponentsToContainer() {
        reset();
        //tags
        container.add(status);
        container.add(speed);
        container.add(rain);
        container.add(rpm);
        container.add(gateOpen);
        container.add(gateDistance);
        //buttons
        container.add(logoutButton);
        container.add(brakeButton);
        container.add(incSpeedButton);
        container.add(decSpeedButton);
        container.add(setRpmButton);
        container.add(rainButton);
        container.add(objOnTrack);
        container.add(obj);
        container.add(gateButton);
        container.add(gateOpenButton);
        //text fields
        container.add(textField);
        stat = true;
    }

    public void addActionEvent() {
        loginButton.addActionListener(this);
        resetButton.addActionListener(this);
        showPassword.addActionListener(this);
        logoutButton.addActionListener(this);
        brakeButton.addActionListener(this);
        incSpeedButton.addActionListener(this);
        decSpeedButton.addActionListener(this);
        setRpmButton.addActionListener(this);
        rainButton.addActionListener(this);
        objOnTrack.addActionListener(this);
        gateButton.addActionListener(this);
        gateOpenButton.addActionListener(this);
    }
    
    //Functions for changing conditions of train
    public void fullyOperational(String op){
        status.setText(op);
        container.revalidate();
        container.repaint();
    }
    
    public void displaySpeed(double num){
      speed.setText("Speed: " + num + " mph");
    }

    public void displayRain(){
      rain.setText("Rain: " + sens.isRaining());
    }

    public void displayRPM(){
      rpm.setText("RPM: " + sens.getRPM());
    }

    public void displayStatus(String change){
      status.setText(change);
    }

    public void displayGateOpen(){
      gateOpen.setText("Gate Open: " + sens.isGateOpen());
    }

    public void displayGateDistance(){
      if (sens.getGateDistance() > 100) {
        gateDistance.setText("Gate Distance: n/a");
      } else {
        gateDistance.setText("Gate Distance: " + sens.getGateDistance() + " mi");
      }
      
    }

    public void displayObj(){
      obj.setText("Object On Track: " + sens.objectOnTrack());
    }

    public static double round(double value, int places) {
      double scale = Math.pow(10, places);
      return Math.round(value * scale) / scale;
    }
    // Interaction with the GUI
    @Override
    public void actionPerformed(ActionEvent e) {
        //Coding Part of LOGIN button
        if (e.getSource() == loginButton) {
            String userText;
            String pwdText;
            userText = userTextField.getText();
            pwdText = passwordField.getText();
            String login = iot.containsLogin(userText, pwdText);
            if (login.equals("conductor")) {
                JOptionPane.showMessageDialog(this, "Conductor Login Successful");
                addDisplayConductorComponentsToContainer();
            } else if(login.equals("admin")) {
                JOptionPane.showMessageDialog(this, "Admin Login Successful");
                addDisplayAdminComponentsToContainer();
            }
            else{
                JOptionPane.showMessageDialog(this, "Invalid Username or Password");
            }
 
        }

        if (e.getSource() == logoutButton) {
          addloginComponentsToContainer(); 
          container.setBackground(Color.WHITE);
          container.repaint();
          sens.reset();
          iot.setLoggedIn(false);
          System.out.println(formatter.format(date) + ": System shut down.");
          iot.turnOff();
        }
        //Coding Part of RESET button
        if (e.getSource() == resetButton) {
            userTextField.setText("");
            passwordField.setText("");
        }
       //Coding Part of showPassword JCheckBox
        if (e.getSource() == showPassword) {
            if (showPassword.isSelected()) {
                passwordField.setEchoChar((char) 0);
            } else {
                passwordField.setEchoChar('*');
            } 
        }
        //Coding Part of BRAKE button
        if (e.getSource() == brakeButton) {
          displayStatus(iot.stopTrain()); 
          sens.setRPM(0);
          System.out.println(formatter.format(date) + ": Brakes applied.");
        }

        if (e.getSource() == incSpeedButton) {
          iot.increaseSpeed(5);
          sens.setRPM(round(iot.getSpeed()*1000/60/1.778/3.14159, 3));
          System.out.println(formatter.format(date) + ": Speed increased.");
        }    

        if (e.getSource() == decSpeedButton) {
          iot.applyBrakes(5);
          sens.setRPM(round(iot.getSpeed()*1000/60/1.778/3.14159, 3));
          System.out.println(formatter.format(date) + ": Speed decreased.");
        }   

        if (e.getSource() == setRpmButton) {
          String field;
          field = textField.getText();
          if (!field.equals("")) {
            double rpm = Double.parseDouble(field);
            if(rpm >= 0){
              sens.setRPM(rpm);
              System.out.println(formatter.format(date) + ": RPM set to " + rpm);
            }
            textField.setText("");
          }
        }   

        if (e.getSource() == gateButton) {
          String field;
          field = textField.getText();
          if (!field.equals("")) {
            double gate = Double.parseDouble(field);
            if(gate >= 0){
              sens.setGateDistance(gate);
              System.out.println(formatter.format(date) + ": Gate is " + gate + " meters away.");
            }
            textField.setText("");
          }
        }   
        
        if (e.getSource() == rainButton) {
          sens.toggleRain();
          if(sens.isRaining()){
            System.out.println(formatter.format(date) + ": It is raining.");
          }else{
            System.out.println(formatter.format(date) + ": It has stopped raining.");
          }
          
        }  

        if(e.getSource() == gateOpenButton){
          sens.toggleGate();
          if(sens.isGateOpen()){
            System.out.println(formatter.format(date) + ": Gate is open.");
          }else{
            System.out.println(formatter.format(date) + ": Gate is closed.");
          }
        }

        if (e.getSource() == objOnTrack) {
          sens.toggleObjectOnTrack();
          if(sens.objectOnTrack()){
            System.out.println(formatter.format(date) + ": Object detected on the track.");
          }else{
            System.out.println(formatter.format(date) + ": Object no longer on the track.");
          }
          
        } 
    }
}