import java.util.*;
import java.io.*;

public class IOTSystem{
  private boolean is_on;
  private boolean loggedIn;
  private double speed;
  private Map<String,String> login;

  public IOTSystem(){
    is_on = false;
    speed = 0;
    login = new HashMap<String,String>();
    login.put("conductor","password1");
    login.put("admin","password2");
  }

  public double getSpeed() {
    return speed;
  }

  //Applies brakes
  public String applyBrakes(double amount){
    double cur_speed = getSpeed();
    if(amount > speed){
      amount = speed;
    }
    decreaseSpeed(amount);
    
    if (getSpeed() == cur_speed) {
      return "Warning: Break failure.";
    }
    return "Brakes applied.";
  }

  //Suggests that the conductor deploy sand
  public String deploySand(){
    return "Deploy Sand.";
  }

  public boolean getLoggedIn(){
    return loggedIn;
  }

  public void setLoggedIn(boolean log){
    loggedIn = log;
  }
  //Measures increase in speed
  public String increaseSpeed(double amount){
    double origSpeed = getSpeed(); 
    speed += amount;
    if (getSpeed() == origSpeed) {
      return "Warning: No acceleration.";
    }
    return "Speed increased.";
  }

  //Measures decrease in speed
  private String decreaseSpeed(double amount){
    double origSpeed = getSpeed(); 
    if(amount == 0){
      return "Cannot slow down, already stopped.";
    }
    speed -= amount;
    if (getSpeed() == origSpeed) {
      return "Warning: No acceleration.";
    }
    return "Speed decreased.";
  }

  //Measures the train breaking
  public String stopTrain(){
    return applyBrakes(getSpeed());
  }

  //Turns on the IoT system
  public String turnOn(){
    is_on = true;
    return"Turning on.";
  }

  //Turns off the IoT system
  public String turnOff(){
    is_on = false;
    return "Turning off.";
  }

  //Checks if the IoT system is on
  public boolean getIsOn(){
    return is_on;
  }

  //Checks login
  public String containsLogin(String username, String password) {
    String psd = login.get(username);
    if (psd != null && psd.equals(password)) {
      return username;
    }
    else
      return "";
  }

  //Creates warning sound
  public void warningSound(){
    //System.out.println("beep beep");
  }
}